import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panic',
  templateUrl: './panic.component.html',
  styleUrls: ['./panic.component.css']
})
export class PanicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
