export const environment = {
  production: true,
  api : "https://forwards.or.id/warga.api/", 
  apiAdmin : "'https://forwards.or.id/admin.api/formresidenceone/", 
};
